import axios from 'axios';

const url = 'https://covid19.mathdro.id/api';

export const fetchData = async (country) => {
  let changeableUrl = url;

  if (country) {
    changeableUrl = `${url}/countries/${country}`;
  }

  try {
    const { data: { confirmed, deaths, lastUpdate } } = await axios.get(changeableUrl);

    return { confirmed, deaths, lastUpdate };
  } catch (error) {
    return error;
  }
};

export const fetchDailyData = async () => {
  try {
    const { data } = await axios.get(`${url}/daily`);

    return data.map(({ confirmed, deaths, reportDate: date }) => ({ confirmed: confirmed.total, deaths: deaths.total, date }));
  } catch (error) {
    return error;
  }
};

export const fetchCountries = async () => {
  try {
    const { data: { countries } } = await axios.get(`${url}/countries`);

    return countries.map((country) => country.name);
  } catch (error) {
    return error;
  }
};

export const fetchStates = async (country) => {
  try {
    const { data } = await axios.get(`${url}/countries/${country.country}/confirmed`);
    return data.map((stateData) => ({ provinceState: stateData.provinceState, confirmed: stateData.confirmed, active: stateData.active, deaths:stateData.deaths}));
  } catch (error) {
    return error;
  }

}